export default async (request, context) => {
  const fail = (message = "Не удалось отправить заявку. Пожалуйста, позвоните нам по телефону +7-918-259-87-87.") =>
    new Response(`<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Не удалось отправить заявку</title><body style="font-family:Arial,sans-serif;max-width:620px;margin:12vh auto;padding:24px;line-height:1.6;color:#18304a"><h1>Заявка не отправлена</h1><p>${message}</p><p><a href="/">Вернуться на сайт</a></p></body></html>`, {
      status: 502, headers: { "content-type": "text/html; charset=utf-8" }
    });

  if (request.method !== "POST") {
    return new Response("Method Not Allowed", { status: 405 });
  }

  try {
    const form = new URLSearchParams(await request.text());
    // Honeypot: если скрытое поле заполнено, не отправляем заявку.
    if (form.get("bot-field")) {
      return Response.redirect(new URL("/spasibo.html", request.url), 303);
    }

    const name = (form.get("name") || "").trim().slice(0, 120);
    const phone = (form.get("phone") || "").trim().slice(0, 40);
    const service = (form.get("service") || "").trim().slice(0, 160);
    const consent = form.get("consent");
    const allowedServices = [
      "Окна",
      "Двери и входные группы",
      "Витражи",
      "Фасады",
      "Террасы и панорамное остекление"
    ];

    if (!name || !phone || !allowedServices.includes(service) || consent !== "yes") {
      return fail("Проверьте имя, телефон, выбранную услугу и согласие на обработку данных, затем отправьте форму ещё раз.");
    }

    const webhook = (process.env.BITRIX_WEBHOOK_URL || "").trim().replace(/\/+$/, "");
    if (!webhook) {
      return fail("Приём заявок временно не настроен. Пожалуйста, позвоните нам по телефону +7-918-259-87-87.");
    }

    const webhookUrl = new URL(webhook);
    if (webhookUrl.protocol !== "https:" || !webhookUrl.hostname.endsWith("bitrix24.ru")) {
      return fail("Настройки подключения CRM требуют проверки. Пожалуйста, позвоните нам по телефону +7-918-259-87-87.");
    }

    const response = await fetch(`${webhook}/crm.lead.add.json`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        fields: {
          TITLE: `Заявка с сайта — ${service}`,
          NAME: name,
          PHONE: [{ VALUE: phone, VALUE_TYPE: "WORK" }],
          SOURCE_DESCRIPTION: "Сайт СК «АБСОЛЮТ» — заявка на расчёт стоимости",
          COMMENTS: `Услуга: ${service}`
        }
      })
    });

    const result = await response.json().catch(() => ({}));
    if (!response.ok || result.error || !result.result) {
      return fail("CRM не подтвердила приём заявки. Пожалуйста, позвоните нам по телефону +7-918-259-87-87.");
    }

    return Response.redirect(new URL("/spasibo.html", request.url), 303);
  } catch (_error) {
    return fail();
  }
};
